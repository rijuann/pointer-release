#!/usr/bin/env bash
# MouseShare Linux Standalone Installer
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}             MouseShare Linux Installer                     ${NC}"
echo -e "${BLUE}============================================================${NC}"

if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[!] Please run as root (sudo ./install.sh)${NC}"
  exit 1
fi

ACTION="${1:-install}"

if [ "$ACTION" = "--uninstall" ] || [ "$ACTION" = "uninstall" ]; then
  echo "[*] Uninstalling MouseShare..."
  rm -f /usr/local/bin/mouseshare
  rm -f /usr/bin/mouseshare
  rm -f /usr/share/applications/mouseshare.desktop
  rm -f /usr/share/icons/hicolor/256x256/apps/mouseshare.png
  rm -f /etc/udev/rules.d/99-mouseshare.rules
  udevadm control --reload-rules 2>/dev/null || true
  update-desktop-database /usr/share/applications 2>/dev/null || true
  echo -e "${GREEN}[+] MouseShare uninstalled successfully.${NC}"
  exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[1/4] Installing binary to /usr/bin/mouseshare..."
install -d /usr/bin
install -m 755 "${SCRIPT_DIR}/mouseshare" /usr/bin/mouseshare

echo "[2/4] Installing desktop launcher and icons..."
install -d /usr/share/applications
install -m 644 "${SCRIPT_DIR}/mouseshare.desktop" /usr/share/applications/

install -d /usr/share/icons/hicolor/256x256/apps
if [ -f "${SCRIPT_DIR}/mouseshare.png" ]; then
  install -m 644 "${SCRIPT_DIR}/mouseshare.png" /usr/share/icons/hicolor/256x256/apps/
fi

echo "[3/4] Installing /dev/uinput permissions rule..."
install -d /etc/udev/rules.d
install -m 644 "${SCRIPT_DIR}/99-mouseshare.rules" /etc/udev/rules.d/
udevadm control --reload-rules 2>/dev/null || true
udevadm trigger /dev/uinput 2>/dev/null || true

TARGET_USER="${SUDO_USER:-$USER}"
if [ -n "$TARGET_USER" ] && [ "$TARGET_USER" != "root" ]; then
  if ! id -nG "$TARGET_USER" 2>/dev/null | grep -qw "input"; then
    echo "[*] Adding user '$TARGET_USER' to 'input' group for /dev/uinput access..."
    usermod -a -G input "$TARGET_USER" || true
    echo -e "${BLUE}[i] Note: You may need to log out and log back in for input group permissions to take effect.${NC}"
  fi
fi

echo "[4/4] Updating system desktop database..."
update-desktop-database /usr/share/applications 2>/dev/null || true
gtk-update-icon-cache -q /usr/share/icons/hicolor 2>/dev/null || true

echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  SUCCESS! MouseShare is installed.                         ${NC}"
echo -e "${GREEN}  Run 'mouseshare' from terminal or launch from Applications${NC}"
echo -e "${GREEN}============================================================${NC}"
